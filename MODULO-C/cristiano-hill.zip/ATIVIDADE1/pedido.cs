using System;
using System.Collections.Generic;

namespace ATIVIDADE1
{
    class Pedido
    {
        private List<itemPedido> itemPedidos;

        public Pedido(){

            itemPedidos = new List<itemPedido>();

        }

        public void AddPedido(/*parametros*/){

        }

        public double TotalPedido(){

            double total = 0;
            //foreach

            return total;
        }
    }

}
