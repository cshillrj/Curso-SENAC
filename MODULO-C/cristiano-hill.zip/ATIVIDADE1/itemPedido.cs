using System;
using System.Collections.Generic;

namespace ATIVIDADE1
{
    class itemPedido
    {
        public string descricao = "";
        public double valor_unitario;
        public int quantidade;
     
    }
}