using System;
using System.Collections.Generic;

namespace ATIV_01
{
    public class ItemPedido
    {
        public string descricao;

        public double valor_unitario;
            
        public double quantidade;
     
    }
}